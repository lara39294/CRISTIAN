<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('empleados')->html();
} elseif ($_instance->childHasBeenRendered('33auE2x')) {
    $componentId = $_instance->getRenderedChildComponentId('33auE2x');
    $componentTag = $_instance->getRenderedChildComponentTagName('33auE2x');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('33auE2x');
} else {
    $response = \Livewire\Livewire::mount('empleados');
    $html = $response->html();
    $_instance->logRenderedChild('33auE2x', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>     
    </div>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/livewire/empleados/index.blade.php ENDPATH**/ ?>