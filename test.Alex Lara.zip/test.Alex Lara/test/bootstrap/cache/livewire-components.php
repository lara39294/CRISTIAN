<?php return array (
  'empleados' => 'App\\Http\\Livewire\\Empleados',
);